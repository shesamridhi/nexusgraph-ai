"""
NexusGraph AI — ChromaDB Vector Store Layer
Handles embedding, chunking, semantic search.
"""
import structlog
import chromadb
from chromadb.config import Settings as ChromaSettings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from typing import List, Dict, Any, Optional
import hashlib
import json

from config import get_settings
from models.schemas import VectorResult

logger = structlog.get_logger(__name__)
settings = get_settings()


class ChromaClient:
    """Async-compatible ChromaDB wrapper with OpenAI embeddings."""

    def __init__(self):
        self._client: Optional[chromadb.AsyncHttpClient] = None
        self._collection = None
        self._embeddings = None
        self._splitter = RecursiveCharacterTextSplitter(
            chunk_size=512,
            chunk_overlap=64,
            separators=["\n\n", "\n", ". ", " ", ""]
        )

    async def connect(self):
        try:
            self._client = await chromadb.AsyncHttpClient(
                host=settings.CHROMA_HOST,
                port=settings.CHROMA_PORT,
            )
        except Exception:
            # Fallback to in-memory for dev/testing
            logger.warning("chroma.http_failed", msg="Falling back to in-memory ChromaDB")
            self._client = chromadb.Client()

        self._collection = await self._client.get_or_create_collection(
            name=settings.CHROMA_COLLECTION,
            metadata={"hnsw:space": "cosine"}
        )
        self._embeddings = OpenAIEmbeddings(
            model=settings.OPENAI_EMBEDDING_MODEL,
            openai_api_key=settings.OPENAI_API_KEY,
        )
        logger.info("chroma.connected", collection=settings.CHROMA_COLLECTION)

    # ── Write ─────────────────────────────────────────────────────────────────

    async def ingest_document(self, doc_id: str, content: str,
                               metadata: Dict[str, Any]) -> int:
        """Chunk, embed, and store a document. Returns number of chunks."""
        chunks = self._splitter.split_text(content)
        if not chunks:
            return 0

        chunk_ids = []
        chunk_texts = []
        chunk_metas = []

        for i, chunk in enumerate(chunks):
            cid = f"{doc_id}__chunk_{i}"
            chunk_ids.append(cid)
            chunk_texts.append(chunk)
            chunk_metas.append({
                **metadata,
                "doc_id": doc_id,
                "chunk_index": i,
                "total_chunks": len(chunks),
            })

        # Batch embed
        embeddings = await self._embeddings.aembed_documents(chunk_texts)

        await self._collection.upsert(
            ids=chunk_ids,
            documents=chunk_texts,
            embeddings=embeddings,
            metadatas=chunk_metas,
        )
        logger.info("chroma.ingested", doc_id=doc_id, chunks=len(chunks))
        return len(chunks)

    # ── Read ──────────────────────────────────────────────────────────────────

    async def similarity_search(self, query: str, top_k: int = None,
                                 filter_meta: Dict = None) -> List[VectorResult]:
        """Semantic similarity search."""
        k = top_k or settings.VECTOR_TOP_K
        query_embedding = await self._embeddings.aembed_query(query)

        kwargs: Dict[str, Any] = {
            "query_embeddings": [query_embedding],
            "n_results": k,
            "include": ["documents", "distances", "metadatas"],
        }
        if filter_meta:
            kwargs["where"] = filter_meta

        results = await self._collection.query(**kwargs)

        output = []
        for i, (doc, dist, meta) in enumerate(zip(
            results["documents"][0],
            results["distances"][0],
            results["metadatas"][0],
        )):
            score = 1.0 - float(dist)  # cosine distance → similarity
            output.append(VectorResult(
                doc_id=meta.get("doc_id", f"chunk_{i}"),
                content=doc,
                score=round(score, 4),
                metadata=meta,
            ))
        return output

    async def get_collection_stats(self) -> Dict[str, Any]:
        count = await self._collection.count()
        return {"collection": settings.CHROMA_COLLECTION, "total_chunks": count}

    async def health_check(self) -> str:
        try:
            await self._collection.count()
            return "healthy"
        except Exception as e:
            return f"error: {str(e)}"

    async def delete_document(self, doc_id: str) -> int:
        """Delete all chunks for a document."""
        results = await self._collection.get(where={"doc_id": doc_id})
        if results["ids"]:
            await self._collection.delete(ids=results["ids"])
        return len(results["ids"])


# Singleton
chroma_client = ChromaClient()
