"""
NexusGraph AI — Configuration & Settings
"""
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # ── App ──────────────────────────────────────────────
    APP_NAME: str = "NexusGraph AI"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False

    # ── OpenAI ───────────────────────────────────────────
    OPENAI_API_KEY: str = "sk-placeholder"
    OPENAI_MODEL: str = "gpt-4o-mini"
    OPENAI_EMBEDDING_MODEL: str = "text-embedding-3-small"

    # ── Neo4j ────────────────────────────────────────────
    NEO4J_URI: str = "bolt://neo4j:7687"
    NEO4J_USER: str = "neo4j"
    NEO4J_PASSWORD: str = "nexusgraph123"

    # ── ChromaDB ─────────────────────────────────────────
    CHROMA_HOST: str = "chromadb"
    CHROMA_PORT: int = 8000
    CHROMA_COLLECTION: str = "nexusgraph_docs"

    # ── LangSmith ────────────────────────────────────────
    LANGCHAIN_TRACING_V2: bool = True
    LANGCHAIN_ENDPOINT: str = "https://api.smith.langchain.com"
    LANGCHAIN_API_KEY: str = "ls-placeholder"
    LANGCHAIN_PROJECT: str = "nexusgraph-ai"

    # ── Retrieval ────────────────────────────────────────
    VECTOR_TOP_K: int = 5
    GRAPH_DEPTH: int = 2
    CRITIC_THRESHOLD: float = 0.7
    MAX_AGENT_ITERATIONS: int = 5

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
